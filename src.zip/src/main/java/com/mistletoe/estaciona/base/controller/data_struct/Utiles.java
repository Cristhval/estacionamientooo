package com.mistletoe.estaciona.base.controller.data_struct;

public class Utiles {
    public static Integer ASCEDENTE = 1;
    public static Integer DESCENDENTE = 2;
    public static Integer START;//1
    public static Integer END;//2
    public static Integer CONSTIANS;//lo que dios quiera

}
