package com.mistletoe.estaciona.base.models;

public enum EstadoTicketEnum {
    PAGADO, PENDIENTE
}
