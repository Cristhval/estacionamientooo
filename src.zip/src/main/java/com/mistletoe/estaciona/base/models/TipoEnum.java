package com.mistletoe.estaciona.base.models;

public enum TipoEnum {
    CARRO, MOTO, CAMION, CUATRIMOTO
}
