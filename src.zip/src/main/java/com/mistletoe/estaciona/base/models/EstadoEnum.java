package com.mistletoe.estaciona.base.models;

public enum EstadoEnum {
    DISPONIBLE, RESERVADO, OCUPADO;
}
