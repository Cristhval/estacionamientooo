package com.mistletoe.estaciona.base.models;

public enum RolEnum {
    ADMINISTRADOR, CLIENTE
}
