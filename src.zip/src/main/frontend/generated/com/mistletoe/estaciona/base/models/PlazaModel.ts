import { _getPropertyModel as _getPropertyModel_1, makeObjectEmptyValueCreator as makeObjectEmptyValueCreator_1, NumberModel as NumberModel_1, ObjectModel as ObjectModel_1, StringModel as StringModel_1 } from "@vaadin/hilla-lit-form";
import EstadoEnumModel_1 from "./EstadoEnumModel.js";
import type Plaza_1 from "./Plaza.js";
class PlazaModel<T extends Plaza_1 = Plaza_1> extends ObjectModel_1<T> {
    static override createEmptyValue = makeObjectEmptyValueCreator_1(PlazaModel);
    get id(): NumberModel_1 {
        return this[_getPropertyModel_1]("id", (parent, key) => new NumberModel_1(parent, key, true, { meta: { javaType: "java.lang.Integer" } }));
    }
    get codigo(): StringModel_1 {
        return this[_getPropertyModel_1]("codigo", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get plazasTotales(): NumberModel_1 {
        return this[_getPropertyModel_1]("plazasTotales", (parent, key) => new NumberModel_1(parent, key, true, { meta: { javaType: "java.lang.Integer" } }));
    }
    get plazasDisponibles(): NumberModel_1 {
        return this[_getPropertyModel_1]("plazasDisponibles", (parent, key) => new NumberModel_1(parent, key, true, { meta: { javaType: "java.lang.Integer" } }));
    }
    get idParqueadero(): NumberModel_1 {
        return this[_getPropertyModel_1]("idParqueadero", (parent, key) => new NumberModel_1(parent, key, true, { meta: { javaType: "java.lang.Integer" } }));
    }
    get estado(): EstadoEnumModel_1 {
        return this[_getPropertyModel_1]("estado", (parent, key) => new EstadoEnumModel_1(parent, key, true));
    }
}
export default PlazaModel;
