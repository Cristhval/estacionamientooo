import { _getPropertyModel as _getPropertyModel_1, makeObjectEmptyValueCreator as makeObjectEmptyValueCreator_1, StringModel as StringModel_1 } from "@vaadin/hilla-lit-form";
import type Persona_1 from "./Persona.js";
import UsuarioModel_1 from "./UsuarioModel.js";
class PersonaModel<T extends Persona_1 = Persona_1> extends UsuarioModel_1<T> {
    static override createEmptyValue = makeObjectEmptyValueCreator_1(PersonaModel);
    get nombre(): StringModel_1 {
        return this[_getPropertyModel_1]("nombre", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get apellido(): StringModel_1 {
        return this[_getPropertyModel_1]("apellido", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
    get correoElectronico(): StringModel_1 {
        return this[_getPropertyModel_1]("correoElectronico", (parent, key) => new StringModel_1(parent, key, true, { meta: { javaType: "java.lang.String" } }));
    }
}
export default PersonaModel;
