import type Usuario_1 from "./Usuario.js";
interface Persona extends Usuario_1 {
    nombre?: string;
    apellido?: string;
    correoElectronico?: string;
}
export default Persona;
