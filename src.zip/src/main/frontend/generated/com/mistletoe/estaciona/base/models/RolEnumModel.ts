import { _enum as _enum_1, EnumModel as EnumModel_1, makeEnumEmptyValueCreator as makeEnumEmptyValueCreator_1 } from "@vaadin/hilla-lit-form";
import RolEnum_1 from "./RolEnum.js";
class RolEnumModel extends EnumModel_1<typeof RolEnum_1> {
    static override createEmptyValue = makeEnumEmptyValueCreator_1(RolEnumModel);
    readonly [_enum_1] = RolEnum_1;
}
export default RolEnumModel;
