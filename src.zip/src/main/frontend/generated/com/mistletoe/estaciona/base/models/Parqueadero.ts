interface Parqueadero {
    id?: number;
    direccion?: string;
    nombre?: string;
}
export default Parqueadero;
