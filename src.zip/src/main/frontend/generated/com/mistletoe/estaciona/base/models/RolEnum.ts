enum RolEnum {
    ADMINISTRADOR = "ADMINISTRADOR",
    CLIENTE = "CLIENTE"
}
export default RolEnum;
