import type RolEnum_1 from "./RolEnum.js";
interface Usuario {
    id?: number;
    usuario?: string;
    clave?: string;
    rol?: RolEnum_1;
}
export default Usuario;
