import type EstadoEnum_1 from "./EstadoEnum.js";
interface Plaza {
    id?: number;
    codigo?: string;
    plazasTotales?: number;
    plazasDisponibles?: number;
    idParqueadero?: number;
    estado?: EstadoEnum_1;
}
export default Plaza;
