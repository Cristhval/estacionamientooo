enum EstadoEnum {
    DISPONIBLE = "DISPONIBLE",
    RESERVADO = "RESERVADO",
    OCUPADO = "OCUPADO"
}
export default EstadoEnum;
