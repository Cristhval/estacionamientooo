import {applyTheme as _applyTheme} from './theme-default.generated.js';
export const applyTheme = _applyTheme;
