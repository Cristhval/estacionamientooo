enum Direction {
    ASC = "ASC",
    DESC = "DESC"
}
export default Direction;
