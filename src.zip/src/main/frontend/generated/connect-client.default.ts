import { ConnectClient as ConnectClient_1 } from "@vaadin/hilla-frontend";
const client_1 = new ConnectClient_1({ prefix: "connect" });
export default client_1;
