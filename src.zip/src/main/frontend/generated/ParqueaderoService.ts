import { EndpointRequestInit as EndpointRequestInit_1 } from "@vaadin/hilla-frontend";
import type Parqueadero_1 from "./com/mistletoe/estaciona/base/models/Parqueadero.js";
import client_1 from "./connect-client.default.js";
async function create_1(nombre: string | undefined, direccion: string | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ParqueaderoService", "create", { nombre, direccion }, init); }
async function delete_1(id: number | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ParqueaderoService", "delete", { id }, init); }
async function getById_1(id: number | undefined, init?: EndpointRequestInit_1): Promise<Parqueadero_1 | undefined> { return client_1.call("ParqueaderoService", "getById", { id }, init); }
async function listAll_1(init?: EndpointRequestInit_1): Promise<Array<Parqueadero_1 | undefined> | undefined> { return client_1.call("ParqueaderoService", "listAll", {}, init); }
async function update_1(id: number | undefined, nombre: string | undefined, direccion: string | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ParqueaderoService", "update", { id, nombre, direccion }, init); }
export { create_1 as create, delete_1 as delete, getById_1 as getById, listAll_1 as listAll, update_1 as update };
